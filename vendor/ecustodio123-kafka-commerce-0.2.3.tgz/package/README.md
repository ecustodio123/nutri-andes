# Kafka Commerce

Kafka Commerce es una libreria React reutilizable para mostrar productos de una tienda usando Supabase como backend compartido.

Esta primera fase incluye:

- `CommerceStore`
- `CommerceProvider`
- `useProducts`
- `useCart`
- `ProductCard`
- `ProductGrid`
- `CartSummary`
- `WhatsAppCheckoutButton`
- sistema de tema con variables CSS
- lectura de productos activos por `store_id`
- carrito persistido por tienda
- checkout por WhatsApp con revalidacion previa
- demo local con Vite

## Instalacion local

```bash
npm install
```

## Configurar la demo

Crea `.env.local` en la raiz del proyecto:

```bash
VITE_SUPABASE_URL=https://tu-proyecto.supabase.co
VITE_SUPABASE_ANON_KEY=tu_anon_key_publica
VITE_STORE_ID=uuid_de_la_tienda
VITE_SECOND_STORE_ID=uuid_de_otra_tienda_opcional
VITE_WHATSAPP_PHONE=519XXXXXXXX
```

Usa la anon key publica de Supabase. No coloques service role keys ni secretos privados en la demo o en sitios cliente.

## Ejecutar la demo

```bash
npm run demo:dev
```

Luego abre la URL que imprime Vite, normalmente `http://localhost:5173`.

## Compilar

```bash
npm run typecheck
npm run build
npm run demo:build
```

O todo junto:

```bash
npm run validate
```

## Empaquetado local

Kafka Commerce aun no esta publicado en npm. Para distribuirlo localmente, genera un paquete `.tgz` desde la raiz de la libreria:

```bash
npm run pack:local
```

Para revisar el contenido sin generar el archivo final:

```bash
npm run pack:check
```

El paquete debe incluir solo los artefactos publicos necesarios:

- `README.md`
- `package.json`
- `dist/kafka-commerce.js`
- `dist/kafka-commerce.cjs`
- `dist/styles.css`
- archivos `*.d.ts` y `*.d.ts.map` dentro de `dist`

No debe incluir `.env`, demos, tests, codigo fuente interno ni credenciales.

Desde un proyecto consumidor, instala el paquete generado:

```bash
npm install ../kafka-commerce/kafka-commerce-0.1.0.tgz
```

Durante desarrollo tambien puedes instalar por ruta local:

```bash
npm install ../kafka-commerce
```

Si regeneras el `.tgz` con cambios, reinstalalo en cada consumidor:

```bash
npm install ../kafka-commerce/kafka-commerce-0.1.0.tgz
```

Si cambias la API publica, actualiza `version` en `package.json`, ejecuta `npm run validate`, vuelve a generar el paquete y reinstalalo en los consumidores.

## Variables de entorno para consumidores

Cada sitio que consuma Kafka Commerce debe configurar sus propias variables:

```bash
VITE_SUPABASE_URL=https://tu-proyecto.supabase.co
VITE_SUPABASE_ANON_KEY=tu_anon_key_publica
VITE_STORE_ID=uuid_o_id_de_la_tienda
VITE_WHATSAPP_PHONE=519XXXXXXXX
```

Usa solo la anon/publishable key de Supabase en frontend. No uses `service_role`, password de base de datos ni secretos privados.

## Uso en una aplicacion React

### Tienda completa

```tsx
import { createClient } from "@supabase/supabase-js";
import { CommerceStore } from "@kafka/commerce";
import "@kafka/commerce/styles.css";

const supabase = createClient(
  import.meta.env.VITE_SUPABASE_URL,
  import.meta.env.VITE_SUPABASE_ANON_KEY
);

export function StorePage() {
  return (
    <CommerceStore
      supabase={supabase}
      storeId={import.meta.env.VITE_STORE_ID}
      checkout={{
        type: "whatsapp",
        phone: import.meta.env.VITE_WHATSAPP_PHONE
      }}
      theme={{
        primary: "#167D68",
        background: "#FFFFFF",
        surface: "#F4F7F5",
        text: "#172B26",
        mutedText: "#64748B",
        border: "#DCE5E1",
        radius: "12px",
        fontFamily: "inherit"
      }}
      features={{
        search: true,
        filters: true,
        cart: true
      }}
    />
  );
}
```

`CommerceStore` incluye catalogo, busqueda local, filtros sencillos, carrito, resumen y checkout por WhatsApp.

Props principales:

- `supabase`: cliente Supabase configurado.
- `storeId`: tienda actual.
- `theme`: tema visual opcional.
- `checkout`: configuracion opcional de WhatsApp.
- `features`: activa/desactiva `search`, `filters` y `cart`.
- `columns` y `gap`: ajuste simple del grid.
- `renderProduct`: reemplazo opcional de tarjeta.

### Componentes independientes

```tsx
import { createClient } from "@supabase/supabase-js";
import {
  CartSummary,
  CommerceProvider,
  ProductGrid,
  WhatsAppCheckoutButton
} from "@kafka/commerce";
import "@kafka/commerce/styles.css";

const supabase = createClient(
  import.meta.env.VITE_SUPABASE_URL,
  import.meta.env.VITE_SUPABASE_ANON_KEY
);

export function StorePage() {
  return (
    <CommerceProvider
      supabase={supabase}
      storeId={import.meta.env.VITE_STORE_ID}
      checkout={{
        type: "whatsapp",
        phone: import.meta.env.VITE_WHATSAPP_PHONE
      }}
      theme={{
        primary: "#167D68",
        background: "#FFFFFF",
        surface: "#F4F7F5",
        text: "#172B26",
        mutedText: "#64748B",
        border: "#DCE5E1",
        radius: "12px",
        fontFamily: "inherit"
      }}
    >
      <ProductGrid columns={3} gap="16px" />
      <CartSummary />
      <WhatsAppCheckoutButton />
    </CommerceProvider>
  );
}
```

## Comunicacion con Supabase

La aplicacion consumidora crea la instancia de Supabase y se la entrega a `CommerceProvider`.

`useProducts` lee `supabase` y `storeId` desde el contexto, llama a `fetchProducts` y expone:

```ts
const { products, loading, error, refetch } = useProducts();
```

La consulta actual:

- lee la tabla `products`
- selecciona solo columnas existentes en el esquema inicial
- filtra por `store_id`
- filtra `active = true`
- ordena por `created_at` descendente
- no realiza escrituras

Si Supabase bloquea la lectura, revisa las politicas RLS. Una politica publica de solo lectura puede verse asi:

```sql
create policy "Public active products are readable"
on public.products
for select
to anon
using (active = true);
```

Evalua esta politica en tu proyecto antes de aplicarla. No otorga permisos de escritura.

## Carrito

El carrito vive dentro de `CommerceProvider`, por lo que cada sitio puede usarlo desde cualquier componente descendiente:

```tsx
import { useCart } from "@kafka/commerce";

export function MiniCartButton() {
  const { itemCount, total, clearCart } = useCart();

  return (
    <button onClick={clearCart}>
      {itemCount} productos - S/ {total}
    </button>
  );
}
```

API principal:

```ts
const {
  items,
  addItem,
  removeItem,
  updateQuantity,
  clearCart,
  itemCount,
  subtotal,
  total
} = useCart();
```

Reglas actuales:

- `addItem(product)` agrega cantidad 1 o incrementa si ya existe.
- productos `available = false` o `active = false` no se agregan.
- `updateQuantity(productId, 0)` elimina el producto.
- cantidades negativas o decimales se ignoran.
- `total = subtotal` en esta fase.
- los calculos usan centimos internamente para evitar errores decimales comunes.

## Persistencia del carrito

El carrito se guarda en `localStorage` con una clave por tienda:

```text
kafka-commerce:cart:<storeId>
```

Esto evita mezclar el carrito de una veterinaria con el de una floreria. Si `localStorage` no esta disponible, el carrito funciona en memoria durante la sesion. Si hay datos corruptos, se limpian y el carrito arranca vacio.

El carrito local no representa una compra confirmada, reserva de inventario ni precio garantizado. El checkout por WhatsApp revalida productos antes de preparar el mensaje, pero el negocio debe confirmar manualmente el pedido.

## Checkout por WhatsApp

Configura el numero por negocio desde la aplicacion consumidora:

```tsx
<CommerceProvider
  supabase={supabase}
  storeId={STORE_ID}
  checkout={{
    type: "whatsapp",
    phone: "519XXXXXXXX"
  }}
>
  <ProductGrid />
  <CartSummary />
  <WhatsAppCheckoutButton />
</CommerceProvider>
```

El numero debe ir en formato internacional, sin `+`, espacios ni guiones.

Antes de abrir WhatsApp, Kafka Commerce:

- toma los productos del carrito actual
- vuelve a consultar `products` en Supabase
- filtra por `store_id`
- verifica que cada producto exista
- verifica `active = true`
- verifica `available = true`
- recalcula precios con datos actuales
- usa `sale_price` u `offer_price` si existen
- genera el mensaje y la URL `https://wa.me/NUMERO?text=...`

Si un producto fue eliminado, desactivado o marcado como agotado, WhatsApp no se abre y se muestran los cambios. Si solo cambio el precio, el carrito se actualiza con el precio vigente y el usuario debe confirmar antes de abrir WhatsApp.

Tambien puedes usar el hook directamente:

```tsx
const {
  prepareCheckout,
  confirmCheckout,
  loading,
  error,
  changes,
  preparedCheckout
} = useCheckout();
```

`prepareCheckout()` valida y prepara el mensaje. `confirmCheckout()` abre WhatsApp usando la URL ya preparada. El carrito no se vacia automaticamente.

## Tema visual

`CommerceProvider` acepta un tema opcional. Si no se proporciona, usa un tema neutral.

```tsx
<CommerceProvider
  supabase={supabase}
  storeId={STORE_ID}
  theme={{
    primary: "#167D68",
    primaryText: "#FFFFFF",
    background: "#FFFFFF",
    surface: "#F4F7F5",
    text: "#172B26",
    mutedText: "#64748B",
    border: "#DCE5E1",
    radius: "12px",
    fontFamily: "inherit"
  }}
>
  <ProductGrid />
</CommerceProvider>
```

Internamente se aplican variables CSS con prefijo propio dentro de la instancia:

```css
--kafka-commerce-primary
--kafka-commerce-background
--kafka-commerce-surface
--kafka-commerce-text
--kafka-commerce-muted
--kafka-commerce-border
--kafka-commerce-radius
--kafka-commerce-font
```

Los consumidores deben importar los estilos distribuidos:

```tsx
import "@kafka/commerce/styles.css";
```

`ProductGrid` permite ajustes simples:

```tsx
<ProductGrid columns={3} gap="16px" />
```

Y tambien permite reemplazar la tarjeta:

```tsx
<ProductGrid
  renderProduct={(product) => (
    <CustomProductCard product={product} />
  )}
/>
```

Los hooks siguen siendo headless. Puedes construir una interfaz completamente personalizada con `useProducts()`, `useCart()` y `useCheckout()` sin usar los componentes visuales incluidos.

Ejemplo headless:

```tsx
function CustomStore() {
  const { products, loading } = useProducts();
  const { addItem, itemCount } = useCart();

  if (loading) {
    return <p>Cargando...</p>;
  }

  return (
    <section>
      <p>Carrito: {itemCount}</p>
      {products.map((product) => (
        <button key={product.id} onClick={() => addItem(product)}>
          {product.name}
        </button>
      ))}
    </section>
  );
}
```

## Busqueda y filtros en CommerceStore

La busqueda de `CommerceStore` es local sobre productos ya cargados por `useProducts()`. Busca por nombre y descripcion, ignora mayusculas, espacios sobrantes y tildes.

Los filtros actuales usan campos ya existentes:

- `Todos`
- `Disponibles`

No consulta Supabase por cada tecla y no modifica los datos originales.

## Instalar en otro proyecto antes de publicar

Desde el proyecto consumidor puedes instalarlo por ruta local:

```bash
npm install ../ruta/a/kafka-commerce
```

Tambien puedes usar un repositorio Git cuando exista:

```bash
npm install git+https://github.com/kafka-tech/kafka-commerce.git
```

El consumidor debe tener React y `@supabase/supabase-js` instalados, porque son peer dependencies.

## Proyectos de prueba locales

Se validaron dos consumidores independientes instalando `@kafka/commerce` desde el `.tgz`, sin importar archivos desde `src`.

### Demo veterinaria

Ruta:

```text
../kafka-demo-veterinaria
```

Usa `CommerceStore` completo con tema verde, catalogo, busqueda, filtros, carrito y checkout por WhatsApp:

```bash
cd ../kafka-demo-veterinaria
npm install
npm run build
npm run dev
```

### Demo barberia

Ruta:

```text
../kafka-demo-barberia
```

Usa la API headless con `CommerceProvider`, `useProducts`, `useCart`, `CartSummary` y `WhatsAppCheckoutButton`, con UI oscura/dorada propia:

```bash
cd ../kafka-demo-barberia
npm install
npm run build
npm run dev
```

Ambas demos leen productos por `store_id`, muestran solo productos activos, resuelven imagenes publicas de Supabase Storage y no realizan escrituras.

## Pendiente para futuras fases

- categorias
- autenticacion
- panel administrativo
- pagos
- pedidos persistidos
- checkout por WhatsApp mas configurable
- pruebas de componentes React
